#!/bin/bash

# 定义颜色
RED='\033[31m'
GREEN='\033[32m'
YELLOW='\033[33m'
RESET='\033[0m'

# Root权限验证
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}\n必须使用Root权限执行!${RESET}"
    exit 1
fi

# 检查 ssh-keygen
if ! command -v ssh-keygen &>/dev/null; then
    echo -e "${RED}\n请使用 MT 管理器扩展包环境执行！${RESET}"
    exit 1
fi

# 默认配置
route="/data/local/tmp/.ssh/"
key="id_ed25519"

# 退出清理
cleanup() {
    echo -e "\n${YELLOW}正在清理并退出...${RESET}"
    exit 0
}

trap cleanup INT TERM

# 欢迎
echo -e "${GREEN}\n欢迎使用辅助签名脚本"
echo -e "TG: Firefly Society${RESET}\n"

running=true
while $running; do
    current_time=$(date "+%Y年-%m月-%d日 %H时:%M分:%S秒")
    echo -e "${GREEN}当前时间: ${current_time}${RESET}\n"

    echo -e "${YELLOW}============= 主菜单 =============${RESET}"
    echo " 1. 跳转添加 lspit 内测群组"
    echo " 2. 辅助通过验证 (生成密钥并签名)"
    echo " 0. 退出脚本"
    echo -e "${YELLOW}==================================${RESET}"
    echo -e -n "${GREEN}请输入选项序号: ${RESET}"
    read -r choice
    echo

    case "$choice" in
        1)
            url="https://t.me/+NfHztfyNBZs2ZDll"
            echo -e "${GREEN}正在尝试打开网址...${RESET}"
            am start -a android.intent.action.VIEW -d "$url" &>/dev/null
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}跳转成功！${RESET}"
            else
                echo -e "${RED}自动跳转失败，请手动打开：${RESET}"
                echo -e "${YELLOW}$url${RESET}"
            fi
            ;;

        2)
            START_TIME=$(date +%s)
            echo -e -n "${YELLOW}请输入 Github 邮箱：${RESET} "
            read -r EMAIL
            echo

            mkdir -p "${route}${EMAIL}"
            ssh-keygen -t ed25519 -C "${EMAIL}" -f "${route}${EMAIL}/${key}" -N "" -q

            echo -e "${GREEN}请把下面内容填入 Github：${RESET}"
            cat "${route}${EMAIL}/${key}.pub"
            echo

            echo -e "${YELLOW}请输入挑战码(直接整串粘贴，不要加引号)：${RESET}"
            read -r code
            echo

            # ------------- 核心修复区 -------------
            # 绝对不会因为引号/转义报错
            export LC_ALL=C
            SIGNED=$(echo -En "$code" | ssh-keygen -Y sign -n lsposed -f "${route}${EMAIL}/${key}")

            echo -e "${GREEN}=====================================${RESET}"
            echo -e "${GREEN}签名结果：${RESET}"
            echo "$SIGNED"
            echo -e "${GREEN}=====================================${RESET}"

            END_TIME=$(date +%s)
            ELAPSED_TIME=$((END_TIME - START_TIME))
            echo -e "\n${GREEN}执行完成，总耗时：${ELAPSED_TIME} 秒${RESET}"
            echo
            ;;

        0)
            echo -e "${GREEN}感谢使用，正在退出...${RESET}"
            running=false
            sleep 1
            exit 0
            ;;

        *)
            echo -e "${RED}输入无效，请重新选择！${RESET}"
            ;;
    esac

    echo -e "\n${YELLOW}----------------------------------${RESET}\n"
done

cleanup
